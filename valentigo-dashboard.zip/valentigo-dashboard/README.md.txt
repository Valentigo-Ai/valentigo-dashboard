# Valentigo Dashboard (Starter)

Next.js + Tailwind starter for Valentigo dashboard (light modern theme).

## Run locally
1. Install:
   npm install

2. Dev:
   npm run dev

## Deploy
Push to GitHub — Vercel will auto-deploy.

## Next steps
- Replace localStorage auth with Supabase/Auth.
- Wire AI endpoints (Gemini/OpenAI) server-side.
- Add DB (Supabase) for leads and logs.
